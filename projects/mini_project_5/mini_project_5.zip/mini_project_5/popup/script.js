// let colorOne=document.getElementById("changeColorOne");


// window.onload = function() {
//   document.getElementById("changeColorOne").onclick = function() {
//     chrome.extension.sendMessage({
//       type: "color-One"
//     });
//   }
//   document.getElementById("changeColorTwo").onclick = function() {
//     chrome.extension.sendMessage({
//       type: "color-Two"
//     });
//   }
//   document.getElementById("changeColorThree").onclick = function() {
//     chrome.extension.sendMessage({
//       type: "color-Three"
//     });
//   }
// }



// when the button in the popup window is clicked...
// colorOne.addEventListener("click", ()=>{
//   // currentValue = currentValue + 1;
//   // console.log(currentValue);
//   // num.innerHTML = currentValue;
//   // })
//
//   chrome.extention.sendMessage({type:"changeColorOne"});
//
//   // chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
//   //   // the browser gives as an array "tabs" containing all tabs that fit
//   //   // out search query: {active: true, currentWindow: true}
//   //   // in our case the array only one tab (tabs[0]) because only
//   //   // one window is active and in it only one tab is active at a time.
//   //
//   //   // the message can be a simple JS object
//   //   let message = {
//   //     find: wordToSearchFor,
//   //     replace: wordToUseInstead
//   //   }
//   //
//   //   // we tell chrome we want to send a message
//   //   // the first argument is the id of the tab we want to contact
//   //   // its the one we were searching for, the active one
//   //   // the second argument is the message
//   //   chrome.tabs.sendMessage(tabs[0].id, message);
//   // });
// })





//-------------class code---------------------
// // let findWord = document.getElementById("findword");
// let num = document.getElementById("number");
// let button = document.getElementById("button");
// let currentValue = 0;
//
//
// chrome.runtime.sendMessage({type:"getCurrentValue"}, function(response) {
//   console.log("response is",response);
//   currentValue = response.value;
//   num.innerHTML = currentValue;
// });
//
// // when the button in the popup window is clicked...
// button.addEventListener("click", ()=>{
//   currentValue = currentValue + 1;
//   console.log(currentValue);
//   num.innerHTML = currentValue;
//   // })
//   chrome.runtime.sendMessage({type:"increasedValue"},(res)=>{console.log(res)});
// })
